import { NgFor } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { DummyService, WeatherForecast } from './dummy.service';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [HttpClientModule, NgFor],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'PregnancyAppFrontend';

  weatherForecasts: WeatherForecast[] = [];

  constructor(private weatherService: DummyService) {}

  ngOnInit(): void {
    this.weatherService.getWeather().subscribe(data => {
      this.weatherForecasts = data;
    });
  }
}
