namespace PregnancyAppBackend;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // 1) Add CORS service
        builder.Services.AddCors(options =>
        {
            options.AddPolicy("AllowAll", policy =>
            {
                policy.AllowAnyOrigin()
                      .AllowAnyMethod()
                      .AllowAnyHeader();
            });
        });

        // Add controllers
        builder.Services.AddControllers();

        // Add OpenAPI/Swagger
        builder.Services.AddOpenApi();

        var app = builder.Build();

        // Map OpenAPI in development
        if (app.Environment.IsDevelopment())
        {
            app.MapOpenApi();
        }

        // 2) Use CORS
        app.UseCors("AllowAll");

        app.UseHttpsRedirection();
        app.UseAuthorization();
        app.MapControllers();

        app.Run();
    }
}
